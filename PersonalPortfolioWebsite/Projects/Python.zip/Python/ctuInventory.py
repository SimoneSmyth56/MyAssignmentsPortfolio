class Inventory:
    def __init__(self, itemNumber, equipment, quantity, cost):
        self.itemNumber = itemNumber
        self.equipment = equipment
        self.quantity = quantity
        self.cost = cost

