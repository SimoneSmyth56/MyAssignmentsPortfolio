class Stock:
    def __init__(self, shopName, shopLocation, customers, sales, returns):
        self.shopName = shopName
        self.shopLocation = shopLocation
        self.customers = customers
        self.sales = sales
        self.returns = returns

